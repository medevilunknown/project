import { useState } from 'react';
import { Layout } from '@/components/layout';
import { Canvas } from '@/components/canvas';
import { BlockLibrary } from '@/components/block-library';
import { PropertiesPanel } from '@/components/properties-panel';
import { Toolbar } from '@/components/toolbar';
import { Block } from '@/lib/blocks';

export default function App() {
  const [selectedBlock, setSelectedBlock] = useState<(Block & { instanceId: number; shape?: string }) | null>(null);

  return (
    <Layout>
      <div className="flex h-screen bg-background">
        <BlockLibrary />
        <div className="flex-1 flex flex-col">
          <Toolbar />
          <Canvas 
            selectedBlock={selectedBlock}
            onSelectBlock={setSelectedBlock}
          />
        </div>
        <PropertiesPanel 
          selectedBlock={selectedBlock}
          onClose={() => setSelectedBlock(null)}
        />
      </div>
    </Layout>
  );
}