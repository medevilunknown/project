import { cn } from '@/lib/utils';
import { useState } from 'react';
import { Block } from '@/lib/blocks';
import { shapeOptions } from '@/lib/shape-options';

interface CanvasProps {
  selectedBlock: Block | null;
  onSelectBlock: (block: Block & { instanceId: number; shape?: string }) => void;
}

export function Canvas({ selectedBlock, onSelectBlock }: CanvasProps) {
  const [blocks, setBlocks] = useState<Array<Block & { instanceId: number; shape?: string }>>([]);

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const blockData = e.dataTransfer.getData('application/json');
    if (blockData) {
      const block = JSON.parse(blockData);
      setBlocks(prev => [...prev, { ...block, instanceId: Date.now(), shape: 'rounded' }]);
    }
  };

  const getShapeClassName = (shape: string) => {
    return shapeOptions.find(option => option.value === shape)?.className || '';
  };

  return (
    <div className="flex-1 bg-background/50 p-6">
      <div 
        className={cn(
          "h-full rounded-lg border-2 border-dashed",
          "flex flex-col gap-4 p-4",
          blocks.length === 0 ? "items-center justify-center" : "items-start"
        )}
        onDragOver={onDragOver}
        onDrop={onDrop}
      >
        {blocks.length === 0 ? (
          <div className="text-muted-foreground">
            Drag and drop blocks here to start building
          </div>
        ) : (
          blocks.map((block) => (
            <div
              key={block.instanceId}
              onClick={() => onSelectBlock(block)}
              className={cn(
                "w-full p-4 border bg-card",
                getShapeClassName(block.shape || 'rounded'),
                "hover:border-primary cursor-pointer transition-colors",
                selectedBlock?.instanceId === block.instanceId && "border-primary"
              )}
            >
              <div className="flex items-center gap-2">
                {block.icon && <block.icon className="h-4 w-4" />}
                <span>{block.label}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}