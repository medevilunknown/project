import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search } from 'lucide-react';
import { blocks } from '@/lib/blocks';
import { useState } from 'react';
import { cn } from '@/lib/utils';

export function BlockLibrary() {
  const [searchQuery, setSearchQuery] = useState('');
  
  const categories = Array.from(new Set(blocks.map(block => block.category)));
  const filteredBlocks = blocks.filter(block => 
    block.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const onDragStart = (e: React.DragEvent, block: any) => {
    e.dataTransfer.setData('application/json', JSON.stringify(block));
  };

  return (
    <div className="w-64 border-r bg-card">
      <div className="p-4 border-b">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search blocks..." 
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      <Tabs defaultValue="elements" className="w-full">
        <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0">
          <TabsTrigger
            value="elements"
            className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary"
          >
            Elements
          </TabsTrigger>
          <TabsTrigger
            value="templates"
            className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary"
          >
            Templates
          </TabsTrigger>
        </TabsList>
        <ScrollArea className="h-[calc(100vh-8rem)]">
          <TabsContent value="elements" className="m-0">
            <div className="grid gap-4 p-4">
              {categories.map(category => {
                const categoryBlocks = filteredBlocks.filter(
                  block => block.category === category
                );
                
                if (categoryBlocks.length === 0) return null;
                
                return (
                  <div key={category}>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">
                      {category}
                    </h3>
                    <div className="grid gap-2">
                      {categoryBlocks.map(block => {
                        const Icon = block.icon;
                        return (
                          <div
                            key={block.id}
                            draggable
                            onDragStart={(e) => onDragStart(e, block)}
                            className={cn(
                              "flex items-center gap-2 rounded-md border bg-card p-2",
                              "hover:bg-accent hover:text-accent-foreground",
                              "cursor-move transition-colors"
                            )}
                          >
                            <Icon className="h-4 w-4" />
                            <span className="text-sm">{block.label}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </TabsContent>
          <TabsContent value="templates" className="m-0">
            <div className="p-4 text-sm text-muted-foreground">
              Templates coming soon...
            </div>
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  );
}