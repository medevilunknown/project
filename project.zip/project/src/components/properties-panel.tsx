import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { X } from 'lucide-react';
import { Block } from '@/lib/blocks';
import { ShapeSelector } from '@/components/shape-selector';
import { useState } from 'react';

interface PropertiesPanelProps {
  selectedBlock: (Block & { instanceId: number; shape?: string }) | null;
  onClose: () => void;
}

export function PropertiesPanel({ selectedBlock, onClose }: PropertiesPanelProps) {
  const [shape, setShape] = useState('rounded');

  if (!selectedBlock) return null;

  return (
    <div className="w-80 border-l bg-card">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-sm font-semibold">{selectedBlock.label} Properties</h2>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <ScrollArea className="h-[calc(100vh-3.5rem)]">
        <div className="p-4 space-y-4">
          <div className="space-y-2">
            <Label>Block Type</Label>
            <Input value={selectedBlock.type} disabled />
          </div>
          <div className="space-y-2">
            <Label>Category</Label>
            <Input value={selectedBlock.category} disabled />
          </div>
          <ShapeSelector value={shape} onChange={setShape} />
          {selectedBlock.defaultProps && Object.entries(selectedBlock.defaultProps).map(([key, value]) => (
            <div key={key} className="space-y-2">
              <Label>{key}</Label>
              <Input defaultValue={value as string} />
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}