import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <ThemeProvider defaultTheme="light" storageKey="ui-theme">
      <main>{children}</main>
      <Toaster />
    </ThemeProvider>
  );
}