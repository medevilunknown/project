import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { shapeOptions } from '@/lib/shape-options';

interface ShapeSelectorProps {
  value: string;
  onChange: (value: string) => void;
}

export function ShapeSelector({ value, onChange }: ShapeSelectorProps) {
  return (
    <div className="space-y-2">
      <Label>Shape</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger>
          <SelectValue placeholder="Select shape" />
        </SelectTrigger>
        <SelectContent>
          {shapeOptions.map((option) => (
            <SelectItem key={option.id} value={option.value}>
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}