import { Button } from '@/components/ui/button';
import {
  Undo2,
  Redo2,
  Smartphone,
  Tablet,
  Monitor,
  Eye,
  Save,
} from 'lucide-react';
import { NavigationDropdown } from '@/components/navigation-dropdown';

export function Toolbar() {
  return (
    <div className="h-14 border-b bg-card px-4 flex items-center justify-between">
      <div className="flex items-center space-x-2">
        <NavigationDropdown />
        <div className="w-px h-6 bg-border mx-2" />
        <Button variant="ghost" size="icon">
          <Undo2 className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon">
          <Redo2 className="h-4 w-4" />
        </Button>
        <div className="w-px h-6 bg-border mx-2" />
        <Button variant="ghost" size="icon">
          <Smartphone className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon">
          <Tablet className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon">
          <Monitor className="h-4 w-4" />
        </Button>
      </div>
      <div className="flex items-center space-x-2">
        <Button variant="ghost" size="sm">
          <Eye className="h-4 w-4 mr-2" />
          Preview
        </Button>
        <Button size="sm">
          <Save className="h-4 w-4 mr-2" />
          Save
        </Button>
      </div>
    </div>
  );
}