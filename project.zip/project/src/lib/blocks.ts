import { 
  Type, 
  Image, 
  FormInput, 
  Button as ButtonIcon, 
  ListOrdered,
  Table2,
  BarChart3,
  MessageSquare,
  Navigation,
  Layout as LayoutIcon
} from 'lucide-react';

export interface Block {
  id: string;
  type: string;
  category: string;
  label: string;
  icon: React.ComponentType;
  defaultProps?: Record<string, any>;
}

export const blocks: Block[] = [
  {
    id: 'heading',
    type: 'heading',
    category: 'Basic',
    label: 'Heading',
    icon: Type,
    defaultProps: {
      text: 'Heading',
      level: 'h1'
    }
  },
  {
    id: 'image',
    type: 'image',
    category: 'Basic',
    label: 'Image',
    icon: Image,
    defaultProps: {
      src: 'https://images.unsplash.com/photo-1706293861851-51c9a63e6f4d',
      alt: 'Image'
    }
  },
  {
    id: 'input',
    type: 'input',
    category: 'Form',
    label: 'Input Field',
    icon: FormInput,
    defaultProps: {
      placeholder: 'Enter text...',
      type: 'text'
    }
  },
  {
    id: 'button',
    type: 'button',
    category: 'Form',
    label: 'Button',
    icon: ButtonIcon,
    defaultProps: {
      text: 'Click me'
    }
  },
  {
    id: 'list',
    type: 'list',
    category: 'Content',
    label: 'List',
    icon: ListOrdered,
    defaultProps: {
      items: ['Item 1', 'Item 2', 'Item 3']
    }
  },
  {
    id: 'table',
    type: 'table',
    category: 'Content',
    label: 'Table',
    icon: Table2
  },
  {
    id: 'chart',
    type: 'chart',
    category: 'Data',
    label: 'Chart',
    icon: BarChart3
  },
  {
    id: 'contact',
    type: 'contact',
    category: 'Form',
    label: 'Contact Form',
    icon: MessageSquare
  },
  {
    id: 'navigation',
    type: 'navigation',
    category: 'Layout',
    label: 'Navigation',
    icon: Navigation
  },
  {
    id: 'section',
    type: 'section',
    category: 'Layout',
    label: 'Section',
    icon: LayoutIcon
  }
];