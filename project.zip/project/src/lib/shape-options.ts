export interface ShapeOption {
  id: string;
  label: string;
  value: string;
  className: string;
}

export const shapeOptions: ShapeOption[] = [
  {
    id: 'square',
    label: 'Square',
    value: 'square',
    className: 'rounded-none',
  },
  {
    id: 'rounded',
    label: 'Rounded',
    value: 'rounded',
    className: 'rounded-md',
  },
  {
    id: 'circle',
    label: 'Circle',
    value: 'circle',
    className: 'rounded-full',
  },
  {
    id: 'pill',
    label: 'Pill',
    value: 'pill',
    className: 'rounded-full px-6',
  },
];